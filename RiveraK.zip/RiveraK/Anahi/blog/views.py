from django.shortcuts import render,redirect
from .models import portafolio
from .models import inicioM
from .models import deporteM
from .models import farandulaM
from .models import Datospersonales
from .models import ExperienciaLaboral
from .forms import Contactform,noticiasformulario,usuarioform,FormDatosPersonales,FormExperienciaLaboral,FormReferencias,FormFormacionAcademica
from django.contrib.auth import authenticate
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView
from django.urls import reverse_lazy
from django.views.generic.edit import UpdateView

from django.contrib import messages




# Create your views here.

def blog (request):
    objCondatos=portafolio.objects.all()
    return render(request,'blog.html',{'Enviablog':objCondatos})

def noticiasH(request):
    objCondatos = portafolio.objects.all()
    if request.method=="POST":
        titulo=request.POST.get('titulo')
        if titulo=='':
            print("ESPACIO EN BLANCO")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos=portafolio.objects.filter(titulo=titulo)
        print(titulo)
    return render(request,'noticiasH.html',{'Enviablog':objCondatos})

def inicioH(request):
    objCondatos =inicioM.objects.all()
    return render(request,'inicioH.html',{'Enviablog':objCondatos})

def deportesH(request):
    objCondatos = deporteM.objects.all()
    return render(request,'deportesH.html',{'Enviablog':objCondatos})

def farandulaH(request):
    objCondatos = farandulaM.objects.all()
    return render(request,'farandulaH.html',{'Enviablog':objCondatos})

def contacto(request):
    objContactos = Contactform()
    print("valida post")
    if request.method=="POST":
        objContactos = Contactform(request.POST)
        print("carga datos del post")
        if objContactos.is_valid():
            print(objContactos)
    return render(request,'contacto.html',{'forms':objContactos})

def addnoticias(request):
    form=noticiasformulario()
    if request.method=="POST":
        form=noticiasformulario(request.POST,request.FILES)
        if form.is_valid():
            isinstance=form.save(commit=False)
            isinstance.save()
            return redirect('/')
        print("Presiono guardar")
    return render(request,'noticiasAgregar.html',{'form':form})

def addmodificar(request,id):
    instancia=portafolio.objects.get(id=id)
    form=noticiasformulario(instance=instancia)
    if request.method=="POST":
        form=noticiasformulario(request.POST,instance=instancia)
        if form.is_valid():
            instance=form.save(commit=False)
            instance.save()
            return redirect('/')
        print("Presiono Modificar")
    return render(request,'noticiasModificar.html',{'form':form})

def eliminarnoticia(request,id):
    instancia = portafolio.objects.get(id=id)
    instancia.delete()
    return redirect('/')

def login(request):
    form=usuarioform()
    if request.method=="POST":
        form=usuarioform(request.POST)
        if form.is_valid():
            username=form.cleaned_data['username']
            password=form.cleaned_data['password']
            user=authenticate(username=request.POST['username'],password=request.POST['password'])
            if user is not None:
                return redirect("form_Datos")
    return render(request, 'login.html', {'form': form})




class noticiasListview(ListView):
    model = portafolio
    paginate_by = 3
    template_name = 'noticiasvistaclase.html'

class noticiasGuardarCreateView (CreateView):
    model = portafolio
    form_class = noticiasformulario
    template_name = 'noticiasGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('noticiasListview')

class noticiasModificarUpdateview(UpdateView):
    model = portafolio
    form_class = noticiasformulario
    template_name = 'noticiasModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('noticiasListview')

def noticiaseliminar(request,id):
    instancia=portafolio.objects.get(id=id)
    instancia.delete()
    return redirect('/')


#---------------Hoja de vida-------------------#

def hojadevida(request):
    objCondatos =Datospersonales.objects.all()
    return render(request,'hoja de vida.html',{'Enviablog':objCondatos})

def formDatos(request):
    form = FormDatosPersonales(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Factura insertada correctamente.')
        form = FormDatosPersonales()
    else:
        messages.error(request, 'Error al insertar factura. Revise los datos.')
    context = {'form': form }
    return render(request, 'Hoja de vida.html', context)

def formExperiencia(request):
    form = FormExperienciaLaboral(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Factura insertada correctamente.')
        form = FormExperienciaLaboral()
    else:
        messages.error(request, 'Error al insertar factura. Revise los datos.')
    context = {'form': form }
    return render(request, 'ExperienciaLaboral.html', context)

def formReferencia(request):
    form = FormReferencias(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Factura insertada correctamente.')
        form = FormReferencias()
    else:
        messages.error(request, 'Error al insertar factura. Revise los datos.')
    context = {'form': form }
    return render(request, 'Referencia.html', context)

def formFormacionAcademica(request):
    form = FormFormacionAcademica(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Factura insertada correctamente.')
        form = FormFormacionAcademica()
    else:
        messages.error(request, 'Error al insertar factura. Revise los datos.')
    context = {'form': form }
    return render(request, 'FormacionAcademica.html', context)


