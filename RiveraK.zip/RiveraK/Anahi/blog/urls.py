from django.urls import path
from.import views
from.views import noticiasListview,noticiasGuardarCreateView,noticiasModificarUpdateview


urlpatterns = [
    path('blog',views.blog,name='blog'),
    path('noticiasH1', views.noticiasH, name='noticiasH1'),
    path('inicioH1', views.inicioH, name='inicioH1'),
    path('deportesH1', views.deportesH, name='deportesH1'),
    path('farandulaH1', views.farandulaH, name='farandulaH1'),
    path('quienessomos', views.contacto, name='quienessomos'),
    path('noticiasAgregar', views.addnoticias, name='noticiasAgregar'),
    path('noticiasModificar/<int:id>', views.addmodificar, name='noticiasModificar'),
    path('noticiaeliminar/<int:id>', views.eliminarnoticia, name='noticiaeliminar'),
    path('',views.login,name='login'),

    path('noticiasListview/',noticiasListview.as_view(),name='noticiasListview'),
    path('noticiasCreateview/', noticiasGuardarCreateView.as_view(),name= 'noticiasCreateview'),
    path('noticiasUpdateview/<int:pk>', noticiasModificarUpdateview.as_view(),name= 'noticiasUpdateview'),
    path('noticiaseliminarview/<int:id>',views.noticiaseliminar,name= 'noticiaseliminarview'),

#------------------Hoja de vida --------------------#

    path('hojadevida', views.hojadevida, name='hojadevida'),
    path('form_Datos', views.formDatos, name='form_Datos'),
    path('form_Experiencia', views.formExperiencia, name='form_Experiencia'),
    path('form_Referencia', views.formReferencia, name='form_Referencia'),
    path('form_FormacionAcademica', views.formFormacionAcademica, name='form_FormacionAcademica'),
]