from django import forms
from .models import portafolio
from .models import Datospersonales
from .models import ExperienciaLaboral
from .models import Referencias
from .models import FormacionAcademica

class Contactform(forms.Form):
    name=forms.CharField(label="Nombre",required=True)
    emai=forms.EmailField(label="Email",required=True)
    contenido=forms.CharField(label="Contenido",required=True)

class noticiasformulario (forms.ModelForm):
    class Meta:
        model= portafolio
        fields=['titulo','contenido','imagen']

class usuarioform(forms.Form):
    username=forms.CharField(label="usuario",required=True,max_length=20)
    password=forms.CharField(label="clave",required=True,max_length=20)

#-----------

class FormDatosPersonales (forms.ModelForm):
    class Meta:
        model = Datospersonales
        fields = ["Nombre", "Apellido", "Telefono", "Direccion", "Email","Cedula","Estado","FechaNacimiento"]

class FormExperienciaLaboral (forms.ModelForm):
    class Meta:
        model = ExperienciaLaboral
        fields = ["Nombredelaempresa", "Cargo", "Jefeinmediato", "Telefono", "TiempoLaborado"]

class FormReferencias (forms.ModelForm):
    class Meta:
        model = Referencias
        fields = ["Nombre", "Ocupacion", "Direccion", "Telefono"]

class FormFormacionAcademica (forms.ModelForm):
    class Meta:
        model = FormacionAcademica
        fields = ["Primaria", "Secundaria", "Carrera"]













