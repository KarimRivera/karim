from django.db import models

# Create your models here.
class portafolio (models.Model):
    titulo=models.CharField(max_length=200)
    contenido=models.TextField()
    imagen=models.ImageField(upload_to="blog")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.titulo

class inicioM (models.Model):
    titulo=models.CharField(max_length=200)
    contenido=models.TextField()
    imagen=models.ImageField(upload_to="blog")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.titulo

class deporteM (models.Model):
    titulo=models.CharField(max_length=200)
    contenido=models.TextField()
    imagen=models.ImageField(upload_to="blog")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.titulo

class farandulaM (models.Model):
    titulo=models.CharField(max_length=200)
    contenido=models.TextField()
    imagen=models.ImageField(upload_to="blog")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.titulo

class contactform (models.Model):
    titulo=models.CharField(max_length=200)
    contenido=models.TextField()
    imagen=models.ImageField(upload_to="blog")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.titulo


class Datospersonales (models.Model):
    Nombre = models.CharField(max_length=50)
    Apellido = models.CharField(max_length=50)
    Telefono= models.CharField(max_length=15)
    Direccion = models.CharField(max_length=50)
    Email = models.CharField(max_length=47)
    Cedula = models.CharField(max_length=48)
    Estado = models.CharField(max_length=48)
    FechaNacimiento = models.DateField()

class ExperienciaLaboral (models.Model):
    Nombredelaempresa = models.CharField(max_length=50)
    Cargo = models.CharField(max_length=50)
    Jefeinmediato = models.CharField(max_length=50)
    Telefono = models.CharField(max_length=15)
    TiempoLaborado = models.DateTimeField(null=True, blank=True)

class Referencias (models.Model):
    Nombre = models.CharField(max_length=50)
    Ocupacion = models.CharField(max_length=60)
    Direccion= models.CharField(max_length=100)
    Telefono= models.CharField(max_length=15)

class FormacionAcademica (models.Model):
    Primaria = models.CharField(max_length=100)
    Secundaria = models.CharField(max_length=100)
    Carrera = models.CharField(max_length=100)




