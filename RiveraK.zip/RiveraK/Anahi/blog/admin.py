from django.contrib import admin
from . models import portafolio
from . models import inicioM
from . models import deporteM
from . models import farandulaM
from . models import contactform

# Register your models here.
admin.site.register(portafolio)
admin.site.register(inicioM)
admin.site.register(deporteM)
admin.site.register(farandulaM)
admin.site.register(contactform)
