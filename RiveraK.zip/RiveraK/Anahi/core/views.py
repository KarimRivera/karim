from django.shortcuts import render

def holamundocore (request):
    return render(request,'core.html')

def noticias(request):
    return render(request,'noticias.html')

def deportes(request):
    return render(request,'deportes.html')

def farandula(request):
    return render(request,'farandula.html')

def sumanumero():
    return 10

#--------------herencia de plantillas-----



