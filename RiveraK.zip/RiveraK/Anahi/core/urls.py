from django.urls import path
from.import views


urlpatterns = [
    path('',views.holamundocore,name='core'),
    path('noticias',views.noticias,name='noticias1'),
    path('deportes',views.deportes,name='deportes1'),
    path('farandula',views.farandula,name='farandula1'),



#----------------herencia------------
]